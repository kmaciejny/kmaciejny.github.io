---
title: Welcome to my blog
---
* The world is focused on new energy as the reliance on Oil products has raised great volatility across financial markets *
